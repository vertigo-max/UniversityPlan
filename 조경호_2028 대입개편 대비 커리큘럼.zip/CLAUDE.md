# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project status

All four stages of `PROMPTS.md` are done: `app.py`, `curriculum.py`, `ai_coach.py`, `data/policy_2028.json` are implemented and the stage-4 audit has been applied.

Read `PRD.md` before changing anything — it is the source of truth for scope. One known gap: PRD §9 targets 15s end-to-end, but the worst case (초1, 12 year plans) measures ~18s; every other grade is under it.

## What is being built

A Streamlit dashboard for Korean parents/students. Input is a single school grade (초1~고1); the app computes the student's college-admission year, generates a year-by-year study curriculum from the current grade through 고3, and visualizes it (Plotly gantt timeline, subject-weight area chart, weekly-hours bars, milestone table). The OpenAI API personalizes the wording of that curriculum. Everything is framed around the 2028 Korean college-admission reform and a 서울대 target.

Stack: Python + Streamlit + pandas + plotly + openai SDK + python-dotenv.
Modules: `app.py` (dashboard) / `curriculum.py` (year math + rule-based skeleton) / `ai_coach.py` (OpenAI) / `data/policy_2028.json` (policy facts).

## Commands

```bash
pip install -r requirements.txt
streamlit run app.py
```

There is no test suite or linter configured.

## Domain rules the design depends on

- **Only 10 grades are valid input**: 초1~초6, 중1~중3, 고1. 고2/고3 must not be selectable — but the *generated plan* still extends through 고3, so the year-plan builder must handle those two stages even though nobody can enter them.
- **Admission year formula** (grade code 초1=1 … 고1=10):
  `대입 학년도 = 기준 학년도 + (12 - 학년코드) + 1`. Base school year rolls over in March, so January–February must resolve to the previous school year. With base 2026: 초1→2038 (12 year plans), 고1→2029 (3 year plans). `PRD.md` §4.2 has the full table; treat it as the regression fixture.
- **Every input grade falls under the 2028 reform**, so the high-school portion of any plan must reflect: 통합사회·통합과학 for 수능 탐구, 내신 5등급 상대평가 (not 9등급), 고교학점제 192학점 and elective design, 심화수학 미출제 (no 미적분Ⅱ/기하), 영어·한국사 절대평가. Pre-reform concepts (9-grade internal scoring, 문·이과 elective tracks) appearing anywhere in code or prompts is a bug, not a style issue.

## Implementation constraints

These are the non-obvious rules that the design depends on:

- **Policy facts live only in `data/policy_2028.json`, never hardcoded in Python or inlined in prompt strings.** The file carries `as_of`/`source` fields because the reform details can still change, and the UI must display that timestamp.
- **The LLM narrates; it never asserts policy.** The system prompt forbids inventing admission rules outside the supplied FACTS + SKELETON. The rule-based skeleton is authoritative — if the model returns a different number of years or malformed fields, merge back onto the skeleton rather than trusting the response.
- **The dashboard must render fully with no API key and on any API failure.** Rule-based curriculum is the baseline product; AI output is an enhancement layered on top.
- **The OpenAI call must be behind an explicit button, with its result cached in `st.session_state`.** Streamlit re-runs the whole script on every widget interaction; without both, moving the study-hours slider re-issues a paid call.
- **Invalidate the cached AI result when the grade or profile inputs change**, or a 고1 plan stays on screen after switching to 초3. 주당 학습 시간 is deliberately excluded from that signature — it only scales the hours chart, so moving the slider must not throw away a paid result; the AI card notes the hours the result was generated with instead.
- **Subject weights must sum to 100** in every year, including after the strength/weakness adjustment.
- **초등 low grades produce up to 12 year plans.** Response generation time — not prompt size — is the bottleneck, so collapse years into fewer prompt units: elementary in 3-year chunks past 7 total years, middle school too past 10 (초1: 12 years → 6 units, ~18s).
- A fixed Korean disclaimer (참고용 / 공식 발표 확인) must stay visible at the bottom — see `PRD.md` §9.
- `OPENAI_API_KEY` (and optional `OPENAI_MODEL`, default `gpt-4o-mini`, `BASE_SCHOOL_YEAR`) come from `.env` via python-dotenv. `.env` already exists and must stay out of version control.

## Working style

The user builds this in four stages (skeleton → features → UI → review), one at a time. Respect the current stage's boundaries: stage 3 is UI-only and must not alter behavior or curriculum output, and stage 4 reports findings for approval before any fixes are applied.

All user-facing strings in the app are Korean.
