"""학년 → 대입 학년도 계산과 연도별 커리큘럼 골격 생성.

이 모듈에는 OpenAI 호출이나 Streamlit 코드가 들어가지 않는다.
규칙 기반 계산만 담당하며, 앱은 이 결과를 표시하기만 한다.

입시 제도 사실(2028 개편 내용)은 이 파일이 아니라 data/policy_2028.json에 있다.
제도가 바뀌면 JSON만 갱신하면 되도록 유지할 것.
"""

from __future__ import annotations

import json
import os
from datetime import date
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# --- 학년 상수 -------------------------------------------------------------

ELEMENTARY_GRADES = [f"초{i}" for i in range(1, 7)]   # 초1 ~ 초6
MIDDLE_GRADES = [f"중{i}" for i in range(1, 4)]       # 중1 ~ 중3
HIGH_GRADES = ["고1", "고2", "고3"]

#: 사용자가 입력할 수 있는 학년 (초1~고1, 총 10개). 이 목록 외의 값은 허용하지 않는다.
SELECTABLE_GRADES = ELEMENTARY_GRADES + MIDDLE_GRADES + ["고1"]

#: 커리큘럼 생성 대상 학년 (고2·고3은 입력할 수 없지만 계획에는 포함된다).
ALL_GRADES = ELEMENTARY_GRADES + MIDDLE_GRADES + HIGH_GRADES

#: 초1=1 … 초6=6, 중1=7 … 중3=9, 고1=10, 고2=11, 고3=12
GRADE_CODE = {grade: code for code, grade in enumerate(ALL_GRADES, start=1)}
CODE_TO_GRADE = {code: grade for grade, code in GRADE_CODE.items()}

FINAL_GRADE_CODE = GRADE_CODE["고3"]  # 12

SUBJECTS = ["국어", "수학", "영어", "탐구", "비교과/진로"]

#: 사용자가 강점/약점으로 고르는 과목 → 커리큘럼 영역 매핑
INPUT_SUBJECTS = ["국어", "수학", "영어", "사회", "과학"]
INPUT_TO_AREA = {"국어": "국어", "수학": "수학", "영어": "영어", "사회": "탐구", "과학": "탐구"}

TRACKS = ["미정", "인문/사회", "자연/공학", "의약생명", "예체능"]

#: 강점/약점 1개당 조정 폭(정규화 전 기준)
WEIGHT_DELTA = 5
MIN_WEIGHT = 5

POLICY_PATH = Path(__file__).parent / "data" / "policy_2028.json"


class PolicyLoadError(Exception):
    """제도 데이터(policy_2028.json)를 읽지 못했을 때."""


# --- 기준 학년도 / 대입 학년도 ---------------------------------------------


def get_base_school_year(today: date | None = None) -> int:
    """현재 학년도를 반환한다.

    학년도는 3월에 바뀌므로 1~2월은 전년도 학년도로 처리한다.
    .env의 BASE_SCHOOL_YEAR가 있으면 그 값을 우선 사용한다(테스트·시연용).
    """
    override = os.getenv("BASE_SCHOOL_YEAR")
    if override:
        try:
            return int(override)
        except ValueError:
            pass  # 잘못된 값이면 무시하고 날짜로 계산한다

    today = today or date.today()
    return today.year - 1 if today.month < 3 else today.year


def validate_grade(grade: str) -> str:
    """입력 학년이 허용된 10개 값인지 검사한다."""
    if grade not in SELECTABLE_GRADES:
        raise ValueError(
            f"허용되지 않은 학년입니다: {grade!r}. "
            f"선택 가능한 값: {', '.join(SELECTABLE_GRADES)}"
        )
    return grade


def calc_admission_year(grade: str, base_year: int | None = None) -> int:
    """대입 학년도 = 기준 학년도 + (12 - 학년코드) + 1"""
    validate_grade(grade)
    base = base_year if base_year is not None else get_base_school_year()
    return base + (FINAL_GRADE_CODE - GRADE_CODE[grade]) + 1


def count_plan_years(grade: str) -> int:
    """현재 학년부터 고3까지의 연도 수(= 남은 준비 기간, 년)."""
    validate_grade(grade)
    return FINAL_GRADE_CODE - GRADE_CODE[grade] + 1


def stage_of(grade: str) -> str:
    """학교급(초등/중등/고등)."""
    code = GRADE_CODE[grade]
    if code <= 6:
        return "초등"
    if code <= 9:
        return "중등"
    return "고등"


# --- 제도 데이터 -----------------------------------------------------------


def load_policy(path: Path | str | None = None) -> dict:
    """2028 개편 제도 데이터를 읽는다.

    파일이 없거나 깨졌으면 PolicyLoadError를 던진다.
    호출하는 쪽은 이를 잡아서 제도 노트 없이도 커리큘럼을 계속 보여줘야 한다.
    """
    path = Path(path) if path else POLICY_PATH
    try:
        with open(path, encoding="utf-8") as f:
            policy = json.load(f)
    except FileNotFoundError as exc:
        raise PolicyLoadError(f"제도 데이터 파일을 찾을 수 없습니다: {path}") from exc
    except json.JSONDecodeError as exc:
        raise PolicyLoadError(f"제도 데이터 파일 형식이 올바르지 않습니다: {exc}") from exc

    if not isinstance(policy, dict) or "facts" not in policy:
        raise PolicyLoadError("제도 데이터에 facts 항목이 없습니다.")
    return policy


def policy_index(policy: dict | None) -> dict[str, dict]:
    """facts와 snu 항목을 id로 찾을 수 있게 합친 색인."""
    if not policy:
        return {}
    items = list(policy.get("facts", [])) + list(policy.get("snu", []))
    return {item["id"]: item for item in items if isinstance(item, dict) and "id" in item}


# --- 커리큘럼 골격 ---------------------------------------------------------

_BANDS = [
    {
        "codes": range(1, 4),  # 초1~초3
        "band": "초등 저학년",
        "headline": "문해력·수 감각·학습 정서의 기초 만들기",
        "goals": [
            "매일 책을 읽고 내용을 자기 말로 설명하는 습관 들이기",
            "연산을 빠르게보다 정확하게 하는 훈련",
            "영어를 소리와 그림책으로 자연스럽게 접하기",
        ],
        "weights": {"국어": 30, "수학": 25, "영어": 20, "탐구": 15, "비교과/진로": 10},
        "actions": {
            "국어": ["매일 20분 소리 내어 읽기", "읽은 책 한 줄 감상 쓰기", "어휘를 문장으로 만들어 보기"],
            "수학": ["학년 연산 정확도 100% 목표", "구체물·그림으로 개념 이해하기", "틀린 문제 다시 설명해 보기"],
            "영어": ["영어 그림책·영상으로 소리 노출", "알파벳과 파닉스 기초", "짧은 문장 따라 말하기"],
            "탐구": ["체험 활동과 자연 관찰", "궁금한 것을 질문으로 적어 보기", "박물관·과학관 방문 후 이야기 나누기"],
            "비교과/진로": ["규칙적인 생활 습관 만들기", "다양한 분야 경험하기"],
        },
        "snu_link": "장기 학습의 토대가 되는 문해력과 학습 정서를 형성하는 시기",
        "risks": ["선행보다 학습 흥미와 습관이 우선", "과도한 사교육으로 인한 학습 피로 주의"],
        "policy_ids": ["written_assessment"],
    },
    {
        "codes": range(4, 7),  # 초4~초6
        "band": "초등 고학년",
        "headline": "독해력 심화·사고력 수학·기록 습관 만들기",
        "goals": [
            "비문학 글을 읽고 요약해서 쓰기",
            "풀이 과정을 문장으로 설명하는 서술형 수학",
            "관찰하고 기록하는 탐구 습관 들이기",
        ],
        "weights": {"국어": 25, "수학": 30, "영어": 20, "탐구": 15, "비교과/진로": 10},
        "actions": {
            "국어": ["비문학 지문 읽고 3문장 요약", "어휘 정리 노트 운영", "주장하는 글 쓰기 연습"],
            "수학": ["개념을 자기 말로 설명하기", "풀이 과정 서술 연습", "단원별 오답 정리"],
            "영어": ["듣기·말하기·읽기·쓰기 균형 학습", "쉬운 원서 읽기", "기초 문법 정리"],
            "탐구": ["실험·관찰 기록장 쓰기", "사회 현상을 뉴스로 이야기 나누기", "사회·과학 배경지식 독서"],
            "비교과/진로": ["관심 분야 독서와 체험", "스스로 주간 학습 계획 세우기"],
        },
        "snu_link": "기록하고 설명하는 습관이 이후 학생부 세특의 기반이 됨",
        "risks": ["진도 위주 선행보다 개념 정확도 우선", "쓰기 훈련을 건너뛰지 말 것"],
        "policy_ids": ["written_assessment", "tamgu_integrated"],
    },
    {
        "codes": range(7, 10),  # 중1~중3
        "band": "중등",
        "headline": "내신 기반 구축·적정 선행·진로 탐색",
        "goals": [
            "중등 내신 관리 루틴 정착",
            "고1 공통 과목으로 이어지는 수학 개념 연결",
            "희망 진로를 탐색하고 고교 과목 이수 계획 초안 만들기",
        ],
        "weights": {"국어": 20, "수학": 30, "영어": 20, "탐구": 20, "비교과/진로": 10},
        "actions": {
            "국어": ["수능형 비문학 지문 접하기", "서술형 답안 작성 연습", "문학 작품 감상문 쓰기"],
            "수학": ["중등 개념 완성 후 고1 공통수학으로 연결", "오답 노트 운영", "서술형 풀이 훈련"],
            "영어": ["수능형 독해 진입", "어휘·문법 체계화", "절대평가 대비 기초 실력 확보"],
            "탐구": ["통합사회·통합과학 배경지식 쌓기", "시사·과학 이슈 정리", "사회·과학 전 영역 균형 학습"],
            "비교과/진로": ["진로 탐색 활동과 독서", "고교 선택과목 정보 수집", "탐구 주제 기록 습관"],
        },
        "snu_link": "고교 과목 선택과 진로 방향을 미리 설계하는 시기",
        "risks": ["무리한 선행보다 내신·개념이 우선", "진로를 너무 좁게 확정하지 말 것"],
        "policy_ids": ["tamgu_integrated", "naesin_5", "credit_system"],
    },
    {
        "codes": range(10, 11),  # 고1
        "band": "고1",
        "headline": "내신 5등급제 대응과 고교학점제 과목 설계",
        "goals": [
            "공통국어·공통수학·공통영어·통합사회·통합과학 내신 관리",
            "수행평가와 세부능력 및 특기사항을 전략적으로 설계",
            "2·3학년 선택과목(전공연계 권장과목) 확정",
        ],
        "weights": {"국어": 20, "수학": 25, "영어": 15, "탐구": 25, "비교과/진로": 15},
        "actions": {
            "국어": ["공통국어 내신과 수능형 독해 병행", "서술형 평가 대비"],
            "수학": ["공통수학 개념 완성", "학교 서술형 문항 유형 분석"],
            "영어": ["절대평가 목표 등급 조기 확보", "내신 지문 정밀 학습"],
            "탐구": ["통합사회·통합과학 내신 집중", "수업 연계 탐구 보고서 작성"],
            "비교과/진로": ["세특으로 이어질 활동 설계", "2·3학년 선택과목 로드맵 확정"],
        },
        "snu_link": "서울대는 정시에서도 교과평가를 반영하므로 고1 내신과 기록이 그대로 자산이 됨",
        "risks": ["내신 5등급제에서 한 과목의 실패가 크게 작용", "선택과목 결정을 미루지 말 것"],
        "policy_ids": ["naesin_5", "credit_system", "tamgu_integrated", "snu_jeongsi_gyogwa"],
    },
    {
        "codes": range(11, 13),  # 고2~고3
        "band": "고2~고3",
        "headline": "선택과목 심화와 수능 실전 대비",
        "goals": [
            "전공연계 선택과목 이수와 심화 탐구",
            "통합형 수능 출제에 맞춘 실전 훈련",
            "수시·정시 지원 전략 확정",
        ],
        "weights": {"국어": 25, "수학": 25, "영어": 15, "탐구": 25, "비교과/진로": 10},
        "actions": {
            "국어": ["수능 국어 실전 연습", "내신과 수능 병행 계획"],
            "수학": ["대수·미적분Ⅰ·확률과통계 범위 완성", "고난도 응용 훈련"],
            "영어": ["절대평가 등급 유지", "시간 관리 훈련"],
            "탐구": ["통합사회·통합과학 실전 대비", "전공연계 심화 탐구 수행"],
            "비교과/진로": ["학생부 기록 마무리", "수시·정시 지원 전략 수립"],
        },
        "snu_link": "전공연계 교과이수와 탐구 기록이 학생부 정성평가의 핵심 근거가 됨",
        "risks": ["내신과 수능 준비의 균형 실패", "탐구 기록을 3학년에 몰아서 만들려는 시도"],
        "policy_ids": [
            "suneung_integrated",
            "math_scope",
            "no_advanced_math",
            "absolute_grading",
            "snu_major_courses",
        ],
    },
]

#: 학년코드별 분기 마일스톤 (분기, 제목, 유형)
_MILESTONES: dict[int, list[tuple[str, str, str]]] = {
    1: [("Q1", "학습 습관과 생활 리듬 잡기", "학습"), ("Q4", "1년간 읽은 책 목록 정리", "학습")],
    2: [("Q2", "소리 내어 읽기 → 묵독으로 전환 점검", "학습"), ("Q4", "한 줄 감상 → 문단 쓰기로 확장", "학습")],
    3: [("Q1", "연산 정확도 점검", "시험"), ("Q3", "관심 분야 체험 활동", "진로")],
    4: [("Q2", "비문학 요약 노트 점검", "학습"), ("Q4", "다음 학년 학습 계획 수립", "학습")],
    5: [("Q1", "서술형 수학 풀이 훈련 시작", "학습"), ("Q3", "실험·관찰 기록장 중간 점검", "학습")],
    6: [("Q2", "중학교 교과 미리보기", "학습"), ("Q4", "중등 학습 루틴 설계", "진로")],
    7: [("Q1", "첫 중간고사 대비 루틴 만들기", "시험"), ("Q3", "진로 흥미 탐색 활동", "진로"), ("Q4", "1년 내신 결과 분석", "시험")],
    8: [("Q2", "수능형 독해·비문학 진입 점검", "학습"), ("Q3", "탐구 주제 기록 시작", "서류"), ("Q4", "고교 선택과목 1차 설계", "진로")],
    9: [("Q1", "중등 내신 마무리 전략", "시험"), ("Q3", "고교 과목 이수 계획 확정", "진로"), ("Q4", "고1 공통과목 예습", "학습")],
    10: [("Q1", "3월 전국연합학력평가", "시험"), ("Q2", "1학기 기말고사·수행평가 마무리", "시험"), ("Q3", "탐구 보고서 작성 및 세특 반영", "서류"), ("Q4", "2·3학년 선택과목 최종 확정", "진로")],
    11: [("Q1", "3월 학력평가로 위치 점검", "시험"), ("Q2", "전공연계 심화 탐구 수행", "서류"), ("Q3", "2학기 내신 집중 관리", "시험"), ("Q4", "3학년 선택과목 확정 및 학생부 점검", "서류")],
    12: [("Q1", "3월 학력평가·내신 최종 학기 시작", "시험"), ("Q2", "6월 모의평가로 지원 전략 1차 수립", "시험"), ("Q3", "9월 모의평가 및 수시 원서 접수", "서류"), ("Q4", "수능 응시 및 정시 지원", "시험")],
}


def _band_for(code: int) -> dict:
    for band in _BANDS:
        if code in band["codes"]:
            return band
    raise ValueError(f"커리큘럼 구간을 찾을 수 없습니다: 학년코드 {code}")


def build_milestones(code: int, year: int) -> list[dict]:
    """해당 학년의 분기별 마일스톤."""
    return [
        {"quarter": f"{year}-{q}", "title": title, "type": kind}
        for q, title, kind in _MILESTONES.get(code, [])
    ]


def policy_notes_for(band: dict, policy: dict | None) -> list[str]:
    """구간에 해당하는 제도 사실 요약 문장."""
    index = policy_index(policy)
    notes = []
    for pid in band.get("policy_ids", []):
        item = index.get(pid)
        if item:
            notes.append(item["summary"])
    return notes


def build_skeleton(
    grade: str,
    base_year: int | None = None,
    policy: dict | None = None,
) -> list[dict]:
    """현재 학년부터 고3까지의 연도별 커리큘럼 골격을 반환한다.

    반환 형식은 PRD 5.2의 스키마를 따른다.
    제도 사실은 policy 인자에서만 가져오며, 없으면 policy_notes가 빈 리스트가 된다.
    """
    validate_grade(grade)
    base = base_year if base_year is not None else get_base_school_year()
    start_code = GRADE_CODE[grade]

    plans = []
    for code in range(start_code, FINAL_GRADE_CODE + 1):
        band = _band_for(code)
        school_year = CODE_TO_GRADE[code]
        year = base + (code - start_code)
        plans.append(
            {
                "year": year,
                "school_year": school_year,
                "stage": stage_of(school_year),
                "band": band["band"],
                "headline": band["headline"],
                "goals": list(band["goals"]),
                "subjects": {
                    subject: {
                        "weight": band["weights"][subject],
                        "actions": list(band["actions"].get(subject, [])),
                    }
                    for subject in SUBJECTS
                },
                "milestones": build_milestones(code, year),
                "snu_link": band["snu_link"],
                "risks": list(band["risks"]),
                "policy_notes": policy_notes_for(band, policy),
            }
        )
    return plans


# --- 학습 비중 보정 --------------------------------------------------------


def _normalize_weights(raw: dict[str, float]) -> dict[str, int]:
    """합이 정확히 100인 정수 비중으로 변환한다(최대잔여법)."""
    total = sum(raw.values())
    if total <= 0:
        equal = 100 // len(raw)
        result = {k: equal for k in raw}
        result[SUBJECTS[0]] += 100 - equal * len(raw)
        return result

    scaled = {k: v * 100 / total for k, v in raw.items()}
    floored = {k: int(v) for k, v in scaled.items()}
    remainder = 100 - sum(floored.values())
    order = sorted(scaled, key=lambda k: scaled[k] - floored[k], reverse=True)
    for key in order[:remainder]:
        floored[key] += 1
    return floored


def adjust_weights(
    plans: list[dict],
    strengths: list[str] | None = None,
    weaknesses: list[str] | None = None,
) -> list[dict]:
    """강점/약점 과목에 따라 영역별 비중을 보정한다.

    약점 과목은 비중을 올리고 강점 과목은 내린다.
    같은 과목을 강점·약점에 모두 넣으면 서로 상쇄되어 변화가 없다.
    보정 후에도 각 연도의 비중 합계는 항상 100이다.
    """
    strengths = strengths or []
    weaknesses = weaknesses or []

    delta: dict[str, float] = {subject: 0.0 for subject in SUBJECTS}
    for subject in weaknesses:
        area = INPUT_TO_AREA.get(subject)
        if area:
            delta[area] += WEIGHT_DELTA
    for subject in strengths:
        area = INPUT_TO_AREA.get(subject)
        if area:
            delta[area] -= WEIGHT_DELTA

    if not any(delta.values()):
        return plans

    adjusted = []
    for plan in plans:
        raw = {
            subject: max(plan["subjects"][subject]["weight"] + delta[subject], MIN_WEIGHT)
            for subject in SUBJECTS
        }
        weights = _normalize_weights(raw)
        new_plan = dict(plan)
        new_plan["subjects"] = {
            subject: {
                "weight": weights[subject],
                "actions": list(plan["subjects"][subject]["actions"]),
            }
            for subject in SUBJECTS
        }
        adjusted.append(new_plan)
    return adjusted


def weight_change_summary(
    base_plans: list[dict], adjusted_plans: list[dict]
) -> list[tuple[str, int, int]]:
    """첫 연도 기준으로 (영역, 원래 비중, 보정 비중) 목록을 반환한다."""
    if not base_plans or not adjusted_plans:
        return []
    before, after = base_plans[0]["subjects"], adjusted_plans[0]["subjects"]
    return [
        (subject, before[subject]["weight"], after[subject]["weight"])
        for subject in SUBJECTS
        if before[subject]["weight"] != after[subject]["weight"]
    ]


# --- 내보내기 --------------------------------------------------------------


def plans_to_rows(plans: list[dict]) -> list[dict]:
    """CSV/표로 쓸 수 있는 평평한 행 목록."""
    rows = []
    for plan in plans:
        row = {
            "연도": plan["year"],
            "학년": plan["school_year"],
            "학교급": plan["stage"],
            "핵심 목표": plan["headline"],
            "주요 목표": " / ".join(plan["goals"]),
        }
        for subject in SUBJECTS:
            row[f"{subject} 비중(%)"] = plan["subjects"][subject]["weight"]
            row[f"{subject} 실행"] = " / ".join(plan["subjects"][subject]["actions"])
        row["마일스톤"] = " / ".join(
            f"{m['quarter']} {m['title']}" for m in plan["milestones"]
        )
        row["서울대 연결"] = plan["snu_link"]
        row["적용 제도"] = " / ".join(plan.get("policy_notes", []))
        row["주의사항"] = " / ".join(plan["risks"])
        rows.append(row)
    return rows


def milestone_rows(plans: list[dict]) -> list[dict]:
    """마일스톤 테이블용 행 목록."""
    return [
        {
            "연도": plan["year"],
            "학년": plan["school_year"],
            "분기": m["quarter"].split("-")[-1],
            "구분": m["type"],
            "내용": m["title"],
        }
        for plan in plans
        for m in plan["milestones"]
    ]
